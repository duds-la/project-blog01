<?php
    include_once("templates/header.php");

?>
    <h1>Página de contato</h1>

    <h2>Ainda em construção :(</h2>
    <?php
    include_once("templates/footer.php");

?>