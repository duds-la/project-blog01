
<footer>
    <p>Hora de Codar &copy; 2023</p>
</footer>
</body>
</html>